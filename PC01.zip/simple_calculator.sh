# !/bin/bash

# Demander les entrées utilisateur
read -p " " a; read -p " " b; read -p " " op

# Calcul selon l’opérateur en utilisant la condition case sur l'opérateur saisi par l'utilisateur

case "$op" in 
     "+")  
         res=$((a + b))
         echo "Résultat : $res"
        ;;
        # Dans le cas ou on choisit +, les commandes au dessus seront exécutéé
    "-")
         res=$((a - b))
          echo "Résultat : $res "
         ;;
          # Dans le cas ou on choisit -, les commandes au dessus seront exécutéé
    "*")
         res=$((a * b))
          echo "Résultat : $res "
           # Dans le cas ou on choisit *, les commandes au dessus seront exécutéé
         ;;
    "/")
        if [ "$b" == 0 ] ; then
            echo "Erreur : Division par zéro impossible."
            exit 1
        else
             res=$((a / b))
             echo "Résultat : $res "
        fi
         # Dans le cas ou on choisit /, les commandes au dessus seront exécutéé
         ;;
     *)
        echo "Erreur : Opérateur non valide. Utilisez +, -, *, ou /."
        exit 1
         # Dans le cas ou on fait une erreur de saisie, les commandes au dessus seront exécutéé
    ;;
esac
    
    
