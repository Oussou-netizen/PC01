# !/bin/bash

# Demander à l’utilisateur de saisir des mots séparés par des espaces 
read -p " " caracteres

# Convertir l’entrée en une liste d’arguments
set -- $caracteres  # remplace $1, $2, etc. par les mots tapés

# Vérifie s’il y a au moins un mot
if [ $# -eq 0 ] ; then
  echo "Aucune entrée fournie."
  exit 1
fi

# Affichage des mots ligne par ligne
i=1
while [ $# -gt 0 ] ; do
  echo "Argument $i : $1"
  shift
  i=$((i + 1))
done

