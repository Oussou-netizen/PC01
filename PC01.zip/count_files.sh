#!/bin/bash
# Script qui compte le nombre de fichiers dans un repertoire

# D'abord on demande le chemin du dossier
read -p " " location

# Ensuite on verifie si le chemin qu'on a saisi mène à un dossier
# Si le chemin ne mène pas à un dossier, alors on précise que ce n'est pas un dossier. 
if [ ! -d "$location" ]; then
    echo "Ce dossier n'existe pas"
    exit 1
else # Sinon on utlise les commandes affectées à la variable compteur pour compter le nombre de fichiers.
    compteur=$(ls -p "$location" | grep -v / | wc -l)
fi

echo "Le dossier $location contient $compteur fichier(s)."
