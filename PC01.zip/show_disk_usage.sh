# !/bin/bash

# Avec la commande df -h, on ffichagera l’utilisation du disque de manière lisible par l'homme
# df pour "Disk free" et -h pour "human readable"
echo "=== Utilisation globale du disque  ==="
df -h 

# On peut afficher l'espace contenu dans le répertoire de notre choix
# En utilisant du
read -p "Entrer le chemin d'un dossier: " path

# On verifie si c'est un repertoire normale accessible
if [ -d "$path" ] ; then #Si oui, on affiche les dossiers et leurs tailles
    echo "=== Détail du dossier $path ==="
    du -h "$path" | sort -hr | head -n 10

  else # Sinon on affiche un message d'erreur
    echo "Erreur : $path n’est pas un dossier valide."
fi

